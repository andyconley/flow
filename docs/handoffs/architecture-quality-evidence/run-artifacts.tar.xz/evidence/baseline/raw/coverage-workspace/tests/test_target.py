import json, os
from pathlib import Path
import cli.jsonl_watermark as target

def test_complete_line_and_offset(tmp_path):
    path = tmp_path / 'events.jsonl'
    path.write_bytes(b'{\"event\": 1}\npartial')
    module_path = Path(target.__file__).resolve()
    assert module_path.is_relative_to(Path.cwd().resolve())
    proof = os.getenv('TARGET_LOAD_PROOF')
    if proof: Path(proof).write_text(json.dumps({'module_file': str(module_path), 'mutant_under_test': os.getenv('MUTANT_UNDER_TEST')}), encoding='utf-8')
    lines, new_offset, size = target.read_new_lines(path, 0)
    assert lines == [b'{\"event\": 1}']
    assert size == len(b'{\"event\": 1}\npartial')
    assert new_offset == len(b'{\"event\": 1}\n')

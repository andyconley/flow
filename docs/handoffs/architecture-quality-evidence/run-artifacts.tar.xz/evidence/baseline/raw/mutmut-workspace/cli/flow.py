#!/usr/bin/env python3
import argparse
import sys
from datetime import datetime
from pathlib import Path

# Sibling modules. The launcher runs cli/flow.py directly, which puts cli/ on
# sys.path — but importing this file programmatically (importlib, as the test
# suite does) does not. Append our own directory so the import holds either way.
# Appended rather than prepended so stdlib still wins on any name collision.
sys.path.append(str(Path(__file__).resolve().parent))

# Every command is implemented in a sibling module; this file owns only the
# argparse declaration and the dispatch that maps parsed args onto them.
#
# The `# noqa: E402` markers are load-bearing, not decoration: these imports
# have to follow the sys.path append above, so they cannot sit at the top of
# the file where E402 expects them.
from archive_commands import register as register_archive, dispatch as dispatch_archive  # noqa: E402
from baseline import baseline_command  # noqa: E402
from cost import (  # noqa: E402
    BUCKET_DAY,
    BUCKET_WEEK,
    DEFAULT_ACTIVE_WITHIN_MINUTES,
    DEFAULT_SESSIONS_LIMIT,
    DEFAULT_WINDOW_DAYS,
    cost_active_command,
    cost_sessions_command,
    cost_summary_command,
    cost_trend_command,
    cost_verdict_command,
    cost_warn_command,
)
from diagnostics import bootstrap, doctor, help_command  # noqa: E402
from gaps import cmd_add, cmd_list, cmd_promote  # noqa: E402
from harvest import harvest_claude_command, harvest_codex_command  # noqa: E402
from lifecycle import install_command, update_command  # noqa: E402
from model_advice import context_command as model_context_command  # noqa: E402
from model_advice import resolve_command as model_resolve_command  # noqa: E402
from normalize import normalize_command  # noqa: E402
from orchestration import cmd_validate as orchestration_validate_command  # noqa: E402
from overlay import overlay_check_command, overlay_status_command  # noqa: E402
from plugin_usage import (  # noqa: E402
    plugin_usage_show_command,
    plugin_usage_snapshot_command,
)
from runstate import (  # noqa: E402
    cmd_history as run_history_command,
    cmd_list as run_list_command,
    cmd_status as run_status_command,
    cmd_transition as run_transition_command,
    cmd_verify as run_verify_command,
)
from runtime_smoke import cmd_smoke as runtime_smoke_command  # noqa: E402
from migrate import cmd_migrate  # noqa: E402
from project import cmd_audit  # noqa: E402
from setup import (  # noqa: E402
    refresh_project,
    setup_machine,
    setup_project,
    setup_user,
)
from sync import sync_target  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="flow",
        description="Portable AI workflow framework CLI.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Common examples:\n"
            "  flow help                          (framework overview)\n"
            "  flow setup machine\n"
            "  flow setup user                    (install at user level)\n"
            "  flow setup project                 (per-repo overlay)\n"
            "  flow bootstrap\n"
            "  flow sync claude --user\n"
            "  flow sync codex --user --check\n"
            "  flow runtime smoke --target all\n"
            "  flow project audit                 (what a repo still copies)\n"
            "  flow run list                      (workflow run state)\n"
            "  flow doctor\n"
            "  flow doctor --json\n"
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True, title="commands")

    setup = sub.add_parser(
        "setup",
        help="prepare the machine install or scaffold .flow into the current repo",
        description="Prepare machine-local flow support or scaffold the project-local .flow source of truth.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  flow setup machine\n"
            "  flow setup project\n"
        ),
    )
    setup_sub = setup.add_subparsers(dest="setup_target", required=True, title="setup targets")
    setup_sub.add_parser(
        "machine",
        help="create ~/.flow support directories, config, and launcher expectations",
        description="Create the machine-local flow home, config, and support directories under ~/.flow.",
    )
    setup_sub.add_parser(
        "project",
        help="scaffold .flow into the current repository",
        description="Copy the project overlay scaffold into repo/.flow without touching existing files.",
    )
    setup_user_parser = setup_sub.add_parser(
        "user",
        help="install flow at the user level so it is active in every supported runtime session",
        description="Generate user-level Claude and Codex skills, agents, hooks, and managed manifests from the framework scaffold.",
    )
    setup_user_parser.add_argument(
        "--overlay-repo",
        metavar="URL",
        help="give ~/.flow/user/ a git home at URL: clone it when the overlay is absent, or init in place and add the remote when it already has content (never clobbers existing files, never commits)",
    )

    refresh = sub.add_parser(
        "refresh",
        help="retired — see `flow setup project` and `flow project migrate`",
        description="Retired. A project overlay no longer holds framework files, so there is nothing to refresh from the scaffold.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Example:\n  flow refresh project\n",
    )
    refresh_sub = refresh.add_subparsers(dest="refresh_target", required=True, title="refresh targets")
    refresh_project_parser = refresh_sub.add_parser(
        "project",
        help="retired — exits 1 and names what replaced it",
        description=(
            "Retired, in every form. Missing core files are `flow setup project`'s "
            "job and it is idempotent; framework copies a project is still carrying "
            "are `flow project audit` and `flow project migrate`'s. Updating an "
            "existing PROJECT.md or STATE.md from the framework template has no "
            "replacement — those are your files once the project exists."
        ),
    )
    refresh_project_parser.add_argument(
        "--all",
        action="store_true",
        help="retired, as is the command itself",
    )
    refresh_project_parser.add_argument(
        "--interactive",
        action="store_true",
        help="retired, as is the command itself",
    )

    harvest = sub.add_parser(
        "harvest",
        help="incrementally read a harness's local session transcripts into the usage store",
        description="Read a harness's local session transcripts into ~/.flow/usage.db, resuming from the last-read position per file.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  flow harvest codex\n"
            "  flow harvest claude\n"
            "  flow harvest claude --rescan --since 2026-08-01 --dry-run\n"
            "  flow harvest claude --rescan --since 2026-08-01\n"
        ),
    )
    harvest_sub = harvest.add_subparsers(dest="harvest_target", required=True, title="harvest targets")
    harvest_sub.add_parser(
        "codex",
        help="harvest ~/.codex/sessions/ into the usage store",
        description="Incrementally read Codex session transcripts, writing session and turn records into the usage store's raw layer.",
    )
    harvest_claude_parser = harvest_sub.add_parser(
        "claude",
        help="harvest ~/.claude/projects/ into the usage store",
        description="Incrementally read Claude Code session transcripts, writing session and turn records into the usage store's raw layer.",
    )
    harvest_claude_parser.add_argument(
        "--rescan",
        action="store_true",
        help="rewind already-recorded files' watermarks first and re-read them from the start, so already-harvested sessions pick up corrected output token counts, compaction events, titles, cwd, and title provenance retroactively",
    )
    harvest_claude_parser.add_argument(
        # The original name for this flag, from when title capture was all it
        # did. Kept working rather than removed: it is in muscle memory and
        # possibly in scripts, and the behaviour it names is a strict subset
        # of what --rescan now does. Hidden so help output teaches one name.
        "--backfill",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    harvest_claude_parser.add_argument(
        "--since",
        metavar="DATE",
        help="with --rescan, only rewind files modified on or after DATE (YYYY-MM-DD or a full ISO timestamp)",
    )
    harvest_claude_parser.add_argument(
        "--session",
        metavar="ID",
        help="with --rescan, only rewind files whose path contains ID — a session uuid reaches that session's main transcript and its subagent files together",
    )
    harvest_claude_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="with --rescan, report how many files and stored turns are in scope and exit without writing anything",
    )

    sub.add_parser(
        "normalize",
        help="recompute the usage store's normalized layer from raw records",
        description="Project every harness's raw turn records into one shared token convention. Only rows without a current-version normalized counterpart are recomputed.",
    )

    cost = sub.add_parser(
        "cost",
        help="read token usage back out of the usage store",
        description="Read `~/.flow/usage.db`'s normalized layer (ensuring the store's schema exists first, like every other command). `summary` and `sessions` never touch turn_raw, turn_norm, or session data; `active` runs the incremental Claude harvest and a normalize pass first so its answer is current.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n  flow cost summary\n  flow cost summary --all --json\n  flow cost sessions --days 30\n  flow cost active\n  flow cost active --within 180\n  flow cost trend --days 30 --bucket week\n  flow cost baseline --all\n",
    )
    cost_sub = cost.add_subparsers(dest="cost_target", required=True, title="cost views")

    cost_summary_parser = cost_sub.add_parser(
        "summary",
        help="token totals by harness/model, plus Codex's capacity gauge",
        description="Token totals grouped by harness and model within the window, plus the most recent Codex capacity reading as a separate gauge line.",
    )
    cost_sessions_parser = cost_sub.add_parser(
        "sessions",
        help="token totals by session, most recently active first",
        description="Token totals grouped by session, within the window, most recently active first.",
    )
    cost_trend_parser = cost_sub.add_parser(
        "trend",
        help="efficiency per time bucket — is session hygiene actually working",
        description="One row per time bucket and harness: main-agent turns, distinct sessions, mean context per turn, input:output, weighted tokens per 1,000 output, subagent share, and compaction events split by trigger. Weighted columns are Claude-only; see data/token_weights.json.",
    )
    cost_trend_parser.add_argument(
        "--bucket",
        choices=(BUCKET_DAY, BUCKET_WEEK),
        default=BUCKET_DAY,
        help=f"bucket size (default: {BUCKET_DAY})",
    )
    cost_trend_parser.add_argument(
        "--harness",
        choices=("claude", "codex"),
        help="restrict to one harness (default: both, one row per bucket per harness)",
    )
    cost_baseline_parser = cost_sub.add_parser(
        "baseline",
        help="the always-on token floor, and when it moved",
        description="The static prefix every session pays before any work — system prompt, tool definitions, MCP instructions, agent and skill descriptions, CLAUDE.md, memory files. Estimated from cache_read_tokens on a session's first turn, where no conversation exists yet, and reported with the changes that cleared threshold. Detects deliberate reconfiguration, not gradual drift; see data/baseline_thresholds.json.",
    )
    cost_baseline_parser.add_argument(
        "--harness",
        choices=("claude", "codex"),
        help="restrict to one harness (default: both, one block each)",
    )
    cost_baseline_parser.add_argument(
        "--by-cwd",
        action="store_true",
        help="estimate per working directory instead of pooling (thins buckets sharply)",
    )
    cost_active_parser = cost_sub.add_parser(
        "active",
        help="context status + /clear-or-/compact recommendation per active session",
        description="Per-active-session context percentage, carry above session start, idle time, and a /clear-or-/compact recommendation — worst carry first. Harvests local Claude/Codex sessions and normalizes incrementally before answering. Supersedes token-report --active.",
    )
    cost_active_parser.add_argument(
        "--within",
        type=int,
        default=DEFAULT_ACTIVE_WITHIN_MINUTES,
        metavar="N",
        help=f"count a session as active if its latest turn is within N minutes (default: {DEFAULT_ACTIVE_WITHIN_MINUTES})",
    )
    cost_active_parser.add_argument(
        "--json",
        action="store_true",
        help="print the same result as JSON instead of an aligned table",
    )
    cost_verdict_parser = cost_sub.add_parser(
        "verdict",
        help="live /clear-or-/compact judgment for one transcript (Stop-hook engine)",
        description="Live judgment for one session: incrementally harvests the transcript, normalizes, and judges carry from the store. --hook reads the runtime's hook JSON on stdin and writes/removes the verdict file silently; --transcript prints the judgment line. Supersedes token-report --verdict.",
    )
    verdict_mode = cost_verdict_parser.add_mutually_exclusive_group(required=True)
    verdict_mode.add_argument(
        "--transcript",
        metavar="PATH",
        help="print the judgment line for this transcript (silence = nothing to say)",
    )
    verdict_mode.add_argument(
        "--hook",
        action="store_true",
        help="Stop-hook mode: read hook JSON from stdin, write/remove the verdict file, print nothing",
    )
    cost_warn_parser = cost_sub.add_parser(
        "warn",
        help="pre-execution context warning (UserPromptSubmit-hook engine)",
        description="Reads the verdict file the Stop hook last wrote — no computation at prompt time — and prints a one-line advisory only when carry is heavy and has grown since the last warning. Informational only; always exits 0.",
    )
    cost_warn_parser.add_argument(
        "--hook",
        action="store_true",
        required=True,
        help="UserPromptSubmit-hook mode: read hook JSON from stdin",
    )
    plugin_usage_parser = sub.add_parser(
        "plugin-usage",
        help="sample and report which installed plugins and skills are actually used",
        description="Samples the plugin and skill usage counters the harness maintains in its own config into flow's store, and reports movement over time. Separate from `flow doctor`, which renders this read model without writing it; doctor may refresh only its machine FTS5 capability receipt.",
    )
    plugin_usage_sub = plugin_usage_parser.add_subparsers(
        dest="plugin_usage_target", required=True
    )
    plugin_usage_snapshot_parser = plugin_usage_sub.add_parser(
        "snapshot",
        help="record the current counters if they have moved since the last look",
        description="Stats the harness config, compares it against the recorded watermark, and stores any state not already held. Safe to run concurrently with `flow harvest`: observations are keyed by their content, so two writers seeing one revision collapse to a single row.",
    )
    plugin_usage_snapshot_parser.add_argument(
        "--hook",
        action="store_true",
        help="SessionStart-hook mode: shorter busy timeout, prints nothing, always exits 0",
    )
    plugin_usage_show_parser = plugin_usage_sub.add_parser(
        "show",
        help="print the usage report `flow doctor` renders as a section",
        description="The same read model doctor renders, standalone. Hook-registering plugins are reported separately from deliberate invocations: the harness increments a plugin's counter once per hook firing, so those numbers measure how many hook events a plugin declares rather than anything a person did.",
    )
    plugin_usage_show_parser.add_argument(
        "--json",
        action="store_true",
        help="emit the payload as JSON instead of the rendered section",
    )
    gaps_parser = sub.add_parser(
        "gaps",
        help="record and read back the capability gaps observed during runs",
        description="The framework's own improvement signal. `flow-archive` appends what the framework was missing during a run; this reads it back so a gap seen from three projects is visible as one recurring problem rather than three unrelated notes. Strictly non-interactive: it never prompts, never commits, and never pushes.",
    )
    gaps_sub = gaps_parser.add_subparsers(dest="gaps_target", required=True)

    gaps_add_parser = gaps_sub.add_parser(
        "add",
        help="record one observed capability gap",
        description="Appends one observation. Idempotent on (key, run), so re-running an archive does not inflate the count. Repeats are detected by the key you supply, never by matching text: read the existing keys with `flow gaps list` and reuse one when the gap is the same gap.",
    )
    gaps_add_parser.add_argument("--key", required=True, help="short slug identifying the gap; reuse an existing one to mark a repeat")
    gaps_add_parser.add_argument("--summary", required=True, help="what the framework was missing")
    gaps_add_parser.add_argument("--project", required=True, help="project the run belonged to")
    gaps_add_parser.add_argument("--run", required=True, help="work id of the run that observed it")
    gaps_add_parser.add_argument("--at", help="ISO timestamp; defaults to now")
    gaps_add_parser.add_argument("--ledger", help="ledger path; defaults to ~/.flow/user/capability-gaps.jsonl")

    gaps_list_parser = gaps_sub.add_parser(
        "list",
        help="show recorded gaps, most-observed first",
        description="Groups observations by key and counts them. A key with more than one sighting is a gap that recurred after being noticed, which is the signal this command exists to surface.",
    )
    gaps_list_parser.add_argument("--json", action="store_true", help="emit the payload as JSON")
    gaps_list_parser.add_argument("--ledger", help="ledger path; defaults to ~/.flow/user/capability-gaps.jsonl")

    gaps_promote_parser = gaps_sub.add_parser(
        "promote",
        help="write one gap into the flow repo's backlog",
        description="Adds the gap to `docs/backlog.md` under `## Deferred / Watch`, never under the ordered Active Priorities — ranking stays the maintainer's decision. Requires ~/.flow/source to be a git work tree; a release install has none, so there it prints a paste-ready entry instead. Never commits and never pushes.",
    )
    gaps_promote_parser.add_argument("--key", required=True, help="key of the gap to promote")
    gaps_promote_parser.add_argument("--at", help="ISO timestamp; defaults to now")
    gaps_promote_parser.add_argument("--ledger", help="ledger path; defaults to ~/.flow/user/capability-gaps.jsonl")

    project_parser = sub.add_parser(
        "project",
        help="inspect this repo's `.flow/` overlay against the framework",
        description="Project-overlay maintenance. `flow setup project` used to copy the whole framework scaffold into a repo, and those copies never updated — so a project set up before the scaffold was thinned still carries its own frozen commands, agents, standards, and templates. These subcommands are how you see which of them are the project's own work and which are stale duplicates, and how you remove the duplicates.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n  flow project audit\n  flow project audit --json\n",
    )
    project_sub = project_parser.add_subparsers(dest="project_target", required=True, title="project views")
    project_audit_parser = project_sub.add_parser(
        "audit",
        help="classify the overlay's capability files against the framework",
        description="Read-only. Walks the overlay's capability paths: standards/, templates/, commands/, agents/, project/, and FRAMEWORK.md. It sorts every entry into identical, differs, project-only, orphaned, or conflict. It also inventories project-local runtime surfaces such as .claude, .codex, and .agents, and reports whether each is absent, unmanaged, or intentionally excluded through [[adoption.exclusions]]. PROJECT.md, flow.toml, memory/, and runs/ are the project's own state and are never visited. Exits 0 whatever it finds: contamination is the normal state of any project created before the overlay was thinned, so a non-zero exit on drift would train everyone to ignore it. It exits 1 only when no audit could be produced at all: no project here, or no framework to compare against.",
    )
    project_audit_parser.add_argument("--json", action="store_true", help="emit the payload as JSON instead of the rendered report")
    project_audit_parser.add_argument("--root", metavar="PATH", help="audit this `.flow` directory instead of the enclosing repo's")
    project_audit_parser.add_argument("--scaffold", metavar="PATH", help="compare against this framework scaffold instead of the installed one")
    project_migrate_parser = project_sub.add_parser(
        "migrate",
        help="remove the framework copies `audit` reports, and the declarations naming them",
        description="Acts on what `flow project audit` reports. Dry run by default: prints exactly which files would be deleted and which `flow.toml` declarations would be removed, and exits 0 without touching anything. Only byte-identical framework copies are removed by default \u2014 `differs` cannot be told apart from a real customization by anything on this machine, so it is reported and left unless you opt in with --drifted, which lists them on its own and removes them only with --apply --yes. The manifest is edited as text rather than parsed and rewritten, so comments and formatting survive.",
    )
    project_migrate_parser.add_argument("--json", action="store_true", help="emit the plan as JSON instead of the rendered report")
    project_migrate_parser.add_argument("--root", metavar="PATH", help="migrate this `.flow` directory instead of the enclosing repo's")
    project_migrate_parser.add_argument("--scaffold", metavar="PATH", help="compare against this framework scaffold instead of the installed one")
    project_migrate_parser.add_argument("--drifted", action="store_true", help="also remove files that differ from the framework; on its own it lists them and exits")
    project_migrate_parser.add_argument("--apply", action="store_true", help="actually remove them; requires --yes")
    project_migrate_parser.add_argument("--yes", action="store_true", help="confirm a destructive --apply run (no interactive prompt exists)")
    project_migrate_parser.add_argument("--at", help="UTC stamp for the backup directory name; defaults to now")


    overlay_parser = sub.add_parser(
        "overlay",
        help="inspect the user overlay's version-control state",
        description="Report and advise on `~/.flow/user/`'s version control. Read-only apart from the nudge's throttle marker; initialization lives in `flow setup user --overlay-repo`.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n  flow overlay status\n",
    )
    overlay_sub = overlay_parser.add_subparsers(dest="overlay_target", required=True, title="overlay views")
    overlay_sub.add_parser(
        "status",
        help="version-control state of the user overlay",
        description="The `doctor` overlay line on its own, plus the remote and the uncommitted paths behind its counts.",
    )
    overlay_check_parser = overlay_sub.add_parser(
        "check",
        help="overlay-commit nudge (PostToolUse / UserPromptSubmit hook engine)",
        description="Prints one advisory line when the overlay's repository has uncommitted or unpushed work, throttled per event. Silent when the overlay is untracked, clean, or absent. Informational only; always exits 0.",
    )
    overlay_check_parser.add_argument(
        "--hook",
        action="store_true",
        required=True,
        help="hook mode: read hook JSON from stdin and branch on hook_event_name",
    )

    run_parser = sub.add_parser(
        "run",
        help="inspect and transition C-lite workflow runs",
        description=(
            "C-lite run protocol. `run.json` is the canonical current state and "
            "`events.jsonl` is append-only transition history. `flow run transition` "
            "is the only command that writes lifecycle state."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  flow run list\n"
            "  flow run status 20260823-work\n"
            "  flow run transition 20260823-work start-definition\n"
            "  flow run transition 20260823-work approve-definition --artifact requirements=.flow/runs/20260823-work/requirements.md --artifact acceptance_criteria=.flow/runs/20260823-work/acceptance-criteria.md\n"
        ),
    )
    run_sub = run_parser.add_subparsers(dest="run_target", required=True, title="run views")
    run_list_parser = run_sub.add_parser(
        "list",
        help="list C-lite and legacy/inferred runs",
        description="List runs under the current repo's `.flow/runs/` directory.",
    )
    run_list_parser.add_argument("--all", action="store_true", help="include archived runs")
    run_list_parser.add_argument("--json", action="store_true", help="emit JSON")

    run_status_parser = run_sub.add_parser(
        "status",
        help="show one run's current state",
        description="Show canonical run state, or legacy/inferred status when no run.json exists.",
    )
    run_status_parser.add_argument("work_id")
    run_status_parser.add_argument("--json", action="store_true", help="emit JSON")

    run_history_parser = run_sub.add_parser(
        "history",
        help="show one run's transition history",
        description="Read events.jsonl for one run.",
    )
    run_history_parser.add_argument("work_id")
    run_history_parser.add_argument("--json", action="store_true", help="emit JSON")

    run_verify_parser = run_sub.add_parser(
        "verify",
        help="verify one run's state/history consistency",
        description="Check run.json, events.jsonl, and the latest projected state.",
    )
    run_verify_parser.add_argument("work_id")
    run_verify_parser.add_argument("--json", action="store_true", help="emit JSON")

    run_transition_parser = run_sub.add_parser(
        "transition",
        help="apply a legal lifecycle transition",
        description="Hard-gated lifecycle transition. Invalid transitions leave run.json and events.jsonl unchanged.",
    )
    run_transition_parser.add_argument("work_id")
    run_transition_parser.add_argument("event")
    run_transition_parser.add_argument(
        "--artifact",
        action="append",
        metavar="NAME=PATH",
        help="record gate evidence or artifact pointer; may be repeated",
    )
    run_transition_parser.add_argument(
        "--disposition",
        action="append",
        metavar="NAME=VALUE",
        help="record a closure disposition such as capability_gaps=n/a; may be repeated",
    )
    run_transition_parser.add_argument("--note", help="next action or transition note")
    run_transition_parser.add_argument("--json", action="store_true", help="emit JSON")

    run_orchestration_parser = run_sub.add_parser(
        "validate-orchestration",
        help="validate a run's orchestration safety contract",
        description=(
            "Read-only structural validation of the run-local orchestration manifest. "
            "Checks declarations, not hidden runtime grants or semantic truth."
        ),
    )
    run_orchestration_parser.add_argument("work_id")
    run_orchestration_parser.add_argument(
        "--stage",
        required=True,
        choices=("dispatch", "handback", "acceptance"),
        help="contract stage to validate",
    )
    run_orchestration_parser.add_argument("--json", action="store_true", help="emit JSON")

    runtime_parser = sub.add_parser(
        "runtime",
        help="inspect generated runtime adapter behavior",
        description="Runtime adapter diagnostics. These commands prove local generated surfaces and list the manual checks needed for client behavior.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n  flow runtime smoke --target all\n  flow runtime smoke --target codex --json\n",
    )
    runtime_sub = runtime_parser.add_subparsers(dest="runtime_target", required=True, title="runtime views")
    runtime_smoke_parser = runtime_sub.add_parser(
        "smoke",
        help="check generated Claude/Codex surfaces and list manual smoke evidence",
        description=(
            "Read-only smoke check for generated runtime files. Static checks cover "
            "skills, agents, hooks, managed manifests, C-lite command protocol text, "
            "and model/effort policy. Actual client command discovery and role-agent "
            "model usage are reported as manual_required."
        ),
    )
    runtime_smoke_parser.add_argument(
        "--target",
        choices=("all", "claude", "codex"),
        default="all",
        help="runtime target to check (default: all)",
    )
    runtime_smoke_parser.add_argument("--json", action="store_true", help="emit JSON")

    model_parser = sub.add_parser(
        "model",
        help="inspect read-only facts and runtime mappings for advisory session model selection",
        description="Read-only session model context and profile resolution. These commands never switch the parent model or configure delegated agents.",
    )
    model_sub = model_parser.add_subparsers(dest="model_target", required=True, title="model views")
    model_context_parser = model_sub.add_parser(
        "context",
        help="collect evidence-qualified facts for the shared session model rubric",
    )
    model_context_parser.add_argument("--runtime", required=True, choices=("claude", "codex"))
    model_context_parser.add_argument(
        "--lane",
        required=True,
        choices=("boot", "define", "solution", "plan", "resume"),
    )
    model_context_parser.add_argument("--parent-model", help="record a user-declared current parent model")
    model_context_parser.add_argument("--parent-effort", help="record user-declared runtime-native effort")
    model_context_parser.add_argument("--parent-source", help="label the declaration source")
    model_context_parser.add_argument("--json", action="store_true", help="emit JSON")
    model_resolve_parser = model_sub.add_parser(
        "resolve",
        help="resolve an agent-selected semantic profile for one runtime",
    )
    model_resolve_parser.add_argument("--runtime", required=True, choices=("claude", "codex"))
    model_resolve_parser.add_argument(
        "--profile",
        required=True,
        choices=("mechanical", "working", "judgment", "demanding"),
    )
    model_resolve_parser.add_argument("--json", action="store_true", help="emit JSON")

    for cost_parser in (
        cost_summary_parser,
        cost_sessions_parser,
        cost_trend_parser,
        cost_baseline_parser,
    ):
        window = cost_parser.add_mutually_exclusive_group()
        window.add_argument(
            "--days",
            type=int,
            default=DEFAULT_WINDOW_DAYS,
            metavar="N",
            help=f"show the last N days (default: {DEFAULT_WINDOW_DAYS})",
        )
        window.add_argument(
            "--all",
            action="store_true",
            help="show every row ever normalized (cannot be combined with --days)",
        )
        cost_parser.add_argument(
            "--json",
            action="store_true",
            help="print the same result as JSON instead of an aligned table",
        )
    cost_sessions_parser.add_argument(
        "--limit",
        type=int,
        default=DEFAULT_SESSIONS_LIMIT,
        metavar="N",
        help=f"cap the number of sessions shown, most recently active first (default: {DEFAULT_SESSIONS_LIMIT}; 0 = unlimited)",
    )

    sub.add_parser(
        "help",
        help="show framework overview (phase machine, commands, agents, architecture)",
        description="Print the framework orientation: workflow phases, slash commands, CLI commands, agents, and architecture. Same content as the `/flow-help` slash command — invoke this at the shell when you are not in a Claude session.",
    )
    register_archive(sub)

    doctor_parser = sub.add_parser(
        "doctor",
        help="report machine, repo, and runtime sync state",
        description="Inspect the current machine install, repo framework, and generated runtime adapter state.",
    )
    doctor_parser.add_argument("--json", action="store_true", help="emit diagnostics; doctor may refresh its machine FTS5 receipt, never project data")
    doctor_parser.add_argument("--check", action="store_true", help="exit nonzero when warning- or error-severity diagnostics exist")
    sub.add_parser(
        "bootstrap",
        help="validate that the required repo/.flow structure exists",
        description="Check that the current repository contains the minimum .flow structure needed for sync and workflow use.",
    )
    sync = sub.add_parser(
        "sync",
        help="generate runtime adapters from the framework scaffold (user level)",
        description="Generate runtime-facing adapters from the framework scaffold, layered with the user overlay. Requires --user: project-level sync was retired, because it existed to regenerate adapters from a project's own copies of the framework and projects no longer hold copies. Without --user this exits 1 and points at `flow project migrate`, which removes the adapters an earlier project-level sync left behind.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Targets:\n"
            "  claude  Generate .claude skills, agents, hooks, settings, and a managed manifest.\n"
            "  codex   Generate .agents skills, .codex agents, hooks, hooks.json, and a managed manifest.\n\n"
            "Examples:\n"
            "  flow sync claude --user\n"
            "  flow sync claude --user --check\n"
            "  flow sync claude --user --check --json\n"
            "  flow sync codex --user\n"
            "  flow sync codex --user --check\n"
        ),
    )
    sync.add_argument(
        "target",
        choices=["claude", "codex"],
        help="runtime adapter target to generate or check",
    )
    sync.add_argument(
        "--check",
        action="store_true",
        help="report drift without writing files",
    )
    sync.add_argument("--json", action="store_true", help="emit a structured diagnostic payload")
    sync.add_argument(
        "--user",
        action="store_true",
        help="required: sync user-level runtime surfaces from the framework scaffold",
    )

    install_parser = sub.add_parser(
        "install",
        help="convert an existing install between develop and release modes",
        description=(
            "Mode conversion for an existing install. Convert ~/.flow/source between "
            "develop mode (symlink to a clone) and release mode (real directory of "
            "copied content). The clone is never deleted; switching to release mode "
            "is non-destructive to the source repo."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  flow install --release\n"
            "  flow install --develop /Users/me/personal/flow\n"
        ),
    )
    install_group = install_parser.add_mutually_exclusive_group(required=True)
    install_group.add_argument(
        "--release",
        action="store_true",
        help="convert ~/.flow/source from a symlink to a real copied directory",
    )
    install_group.add_argument(
        "--develop",
        metavar="CLONE_PATH",
        help="convert ~/.flow/source to a symlink pointing at the given clone path",
    )

    update_parser = sub.add_parser(
        "update",
        help="update a release install to the latest tagged release",
        description=(
            "In release mode: fetch the latest semver tag from the configured remote, "
            "stage it, and atomically swap into ~/.flow/source. In develop mode: print "
            "the manual pull-and-resync commands."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  flow update --check\n"
            "  flow update --check --json\n"
            "  flow update\n"
            "  flow update --resync\n"
        ),
    )
    update_parser.add_argument(
        "--check",
        action="store_true",
        help="report current vs latest tag without applying changes",
    )
    update_parser.add_argument(
        "--resync",
        action="store_true",
        help="after applying, run `flow sync claude --user` and `flow sync codex --user`",
    )
    update_parser.add_argument(
        "--remote",
        metavar="URL",
        help="override the remote URL configured in ~/.flow/config.toml",
    )
    update_parser.add_argument("--json", action="store_true", help="emit a structured diagnostic payload")

    args = parser.parse_args()

    if args.command == "setup" and args.setup_target == "machine":
        return setup_machine()
    if args.command == "setup" and args.setup_target == "project":
        return setup_project()
    if args.command == "setup" and args.setup_target == "user":
        return setup_user(overlay_repo=args.overlay_repo)
    if args.command == "refresh" and args.refresh_target == "project":
        return refresh_project(all_files=args.all, interactive=args.interactive)
    if args.command == "harvest" and args.harvest_target == "codex":
        return harvest_codex_command()
    if args.command == "harvest" and args.harvest_target == "claude":
        rescan = args.rescan or args.backfill
        # The narrowing flags do nothing without a rescan to narrow, so
        # accepting them alone would silently run a plain incremental harvest
        # while the caller believed they had scoped something — including
        # `--dry-run`, which would then write. Refused rather than ignored.
        if not rescan and (args.since or args.session or args.dry_run):
            parser.error("--since, --session, and --dry-run require --rescan")
        if args.since is not None:
            # Parsed here rather than left to blow up inside the command: an
            # unparseable date is a usage error, and a raw ValueError
            # traceback reads as a crash in the tool rather than a typo.
            try:
                datetime.fromisoformat(args.since)
            except ValueError:
                parser.error(
                    f"--since: {args.since!r} is not a date — "
                    f"use YYYY-MM-DD or a full ISO timestamp"
                )
        return harvest_claude_command(
            rescan=rescan,
            since=args.since,
            session=args.session,
            dry_run=args.dry_run,
        )
    if args.command == "normalize":
        return normalize_command()
    if args.command == "cost" and args.cost_target == "summary":
        return cost_summary_command(days=args.days, show_all=args.all, as_json=args.json)
    if args.command == "cost" and args.cost_target == "sessions":
        return cost_sessions_command(days=args.days, show_all=args.all, as_json=args.json, limit=args.limit)
    if args.command == "cost" and args.cost_target == "trend":
        return cost_trend_command(
            days=args.days,
            show_all=args.all,
            bucket=args.bucket,
            harness=args.harness,
            as_json=args.json,
        )
    if args.command == "cost" and args.cost_target == "baseline":
        return baseline_command(
            days=args.days,
            show_all=args.all,
            harness=args.harness,
            by_cwd=args.by_cwd,
            as_json=args.json,
        )
    if args.command == "cost" and args.cost_target == "active":
        return cost_active_command(within=args.within, as_json=args.json)
    if args.command == "cost" and args.cost_target == "verdict":
        return cost_verdict_command(transcript=args.transcript, hook=args.hook)
    if args.command == "cost" and args.cost_target == "warn":
        return cost_warn_command()
    if args.command == "plugin-usage" and args.plugin_usage_target == "snapshot":
        return plugin_usage_snapshot_command(hook=args.hook)
    if args.command == "plugin-usage" and args.plugin_usage_target == "show":
        return plugin_usage_show_command(as_json=args.json)
    if args.command == "gaps" and args.gaps_target == "add":
        return cmd_add(args)
    if args.command == "gaps" and args.gaps_target == "list":
        return cmd_list(args)
    if args.command == "gaps" and args.gaps_target == "promote":
        return cmd_promote(args)
    if args.command == "project" and args.project_target == "audit":
        return cmd_audit(args)
    if args.command == "project" and args.project_target == "migrate":
        return cmd_migrate(args)
    if args.command == "overlay" and args.overlay_target == "status":
        return overlay_status_command()
    if args.command == "overlay" and args.overlay_target == "check":
        return overlay_check_command()
    if args.command == "run" and args.run_target == "list":
        return run_list_command(args)
    if args.command == "run" and args.run_target == "status":
        return run_status_command(args)
    if args.command == "run" and args.run_target == "history":
        return run_history_command(args)
    if args.command == "run" and args.run_target == "verify":
        return run_verify_command(args)
    if args.command in {"archive", "index"}:
        return dispatch_archive(args)
    if args.command == "run" and args.run_target == "transition":
        if args.event in {"archive", "archive-scout"}:
            from archive_service import archive_transition
            return archive_transition(args)
        return run_transition_command(args)
    if args.command == "run" and args.run_target == "validate-orchestration":
        return orchestration_validate_command(args)
    if args.command == "runtime" and args.runtime_target == "smoke":
        return runtime_smoke_command(args)
    if args.command == "model" and args.model_target == "context":
        return model_context_command(args)
    if args.command == "model" and args.model_target == "resolve":
        return model_resolve_command(args)
    if args.command == "help":
        return help_command()
    if args.command == "doctor":
        return doctor(as_json=args.json, check=args.check)
    if args.command == "bootstrap":
        return bootstrap()
    if args.command == "sync":
        return sync_target(args.target, check=args.check, user_mode=args.user, as_json=args.json)
    if args.command == "install":
        result = install_command(release=args.release, develop_path=args.develop)
        if result == 0:
            from archive_preflight import report
            report()
        return result
    if args.command == "update":
        if args.json and not args.check:
            parser.error("flow update --json requires --check")
        result = update_command(check=args.check, resync=args.resync, remote_override=args.remote, as_json=args.json)
        if result == 0 and not args.check:
            from archive_preflight import report
            report()
        return result
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

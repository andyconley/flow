"""SQLite store for harvested harness usage data.

Holds per-turn token usage collected from agent-harness transcripts (Claude
Code, Codex) so flow can report on consumption and, later, advise on it.

Two layers, deliberately:

  raw       `session` + `turn_raw` — what the harness actually said, in its
            own semantics, including the source record verbatim. Durable.
  derived   `turn_norm` — one convention across harnesses. Disposable and
            recomputable from raw at any time.

The split exists because the harnesses disagree about what their own numbers
mean. Codex reports `cached_input_tokens` as a *subset* of `input_tokens`;
Claude's cache buckets are disjoint from its input tokens and are summed. A
single shared column would make cross-harness totals quietly wrong. Rather
than transform on write and hope the rule is right, raw keeps each harness's
meaning and the normalized layer is regenerated whenever the rule changes.

That property is what makes the retention promise survivable: history is never
rebuilt, because a wrong normalization rule costs a recompute, not a re-harvest.

No module-level path constant on purpose. Resolving the store location at
import time would mean a directly-imported unit test operates on the real
~/.flow/usage.db. Callers pass a path; `default_store_path()` resolves lazily.
"""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = 6

STATE_ABSENT = "absent"
STATE_OK = "ok"
STATE_EMPTY = "empty"
STATE_STALE = "stale"
STATE_ERROR = "error"


def default_store_path(home: Path | None = None) -> Path:
    """Resolve the store path lazily. See module docstring for why not a constant."""
    base = home if home is not None else Path.home()
    return base / ".flow" / "usage.db"


def default_capabilities_path(source_dir: Path) -> Path:
    return source_dir / "data" / "harness_capabilities.json"


# --------------------------------------------------------------------------
# migrations — forward-only, additive, never destructive
#
# Every entry is (version, description, sql). A migration may add tables,
# columns, or indexes. It may not drop or rewrite anything: history has to
# survive every schema change, so a correction that needs existing rows
# rewritten is not a migration — it is a normalized-layer recompute.
# --------------------------------------------------------------------------

_V1 = """
CREATE TABLE IF NOT EXISTS schema_migration (
  version     INTEGER PRIMARY KEY,
  applied_at  TEXT NOT NULL,
  description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS harness_capability (
  harness   TEXT NOT NULL,
  field     TEXT NOT NULL,
  supported INTEGER NOT NULL CHECK (supported IN (0, 1)),
  PRIMARY KEY (harness, field)
);

CREATE TABLE IF NOT EXISTS harvest (
  harness           TEXT NOT NULL,
  source_path       TEXT NOT NULL,
  host_id           TEXT NOT NULL DEFAULT '',
  last_size         INTEGER NOT NULL,
  last_offset       INTEGER NOT NULL,
  last_line_no      INTEGER NOT NULL,
  last_line_hash    TEXT,
  file_mtime        REAL,
  harvested_at      TEXT NOT NULL,
  collector_version INTEGER NOT NULL,
  PRIMARY KEY (harness, source_path, host_id)
);

CREATE TABLE IF NOT EXISTS session (
  id                INTEGER PRIMARY KEY,
  harness           TEXT NOT NULL CHECK (harness IN ('claude', 'codex')),
  session_id        TEXT NOT NULL,
  parent_session_id TEXT,
  started_at        TEXT,
  cwd               TEXT,
  title             TEXT,
  UNIQUE (harness, session_id)
);

CREATE TABLE IF NOT EXISTS turn_raw (
  id                INTEGER PRIMARY KEY,
  session_row_id    INTEGER NOT NULL REFERENCES session(id),
  natural_turn_id   TEXT,
  turn_seq          INTEGER NOT NULL,
  is_subagent       INTEGER NOT NULL DEFAULT 0 CHECK (is_subagent IN (0, 1)),
  ts                TEXT NOT NULL,
  model             TEXT,
  payload           TEXT NOT NULL,
  source_path       TEXT NOT NULL,
  source_line_no    INTEGER NOT NULL,
  collector_version INTEGER NOT NULL,
  UNIQUE (session_row_id, natural_turn_id)
);

CREATE TABLE IF NOT EXISTS turn_norm (
  turn_raw_id                     INTEGER PRIMARY KEY
                                  REFERENCES turn_raw(id) ON DELETE CASCADE,
  ts                              TEXT NOT NULL,
  model                           TEXT,
  is_subagent                     INTEGER NOT NULL,
  fresh_input_tokens              INTEGER,
  cache_read_tokens               INTEGER,
  cache_write_tokens              INTEGER,
  output_tokens                   INTEGER,
  reasoning_tokens                INTEGER,
  context_window                  INTEGER,
  capacity_primary_used_pct       REAL,
  capacity_primary_window_minutes INTEGER,
  capacity_primary_resets_at      INTEGER,
  norm_version                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_turn_raw_session_ts ON turn_raw(session_row_id, ts);
CREATE INDEX IF NOT EXISTS idx_norm_ts             ON turn_norm(ts);
CREATE INDEX IF NOT EXISTS idx_norm_model_ts       ON turn_norm(model, ts);
"""

_V2 = """
-- A collector resuming a file mid-stream needs to find the session row for a
-- batch that doesn't include the session_meta line (already committed in an
-- earlier run). Without a direct pointer, that lookup has to infer the
-- session from a child row — turn_raw or agent_activity_raw — which does not
-- exist yet if the very first harvest of a file stopped (truncated write, or
-- a hard-stop) before writing any. source_path is nullable because it is a
-- convenience index for that one fallback path, not part of session
-- identity — (harness, session_id) remains the real key.
ALTER TABLE session ADD COLUMN source_path TEXT;
CREATE INDEX idx_session_source_path ON session(source_path);

-- Coarse activity log for events that describe an agent acting, but carry no
-- token usage of their own. First observed as Codex's `sub_agent_activity`
-- telemetry, which references an `agent_thread_id` matching no local session
-- file — almost certainly a cloud/background agent whose transcript and token
-- usage live server-side, not on this disk. There is nothing to normalize
-- here and no token_norm-shaped counterpart: this table exists so the event
-- itself is not silently dropped, not to make it queryable as usage.
CREATE TABLE agent_activity_raw (
  id                INTEGER PRIMARY KEY,
  session_row_id    INTEGER NOT NULL REFERENCES session(id),
  ts                TEXT NOT NULL,
  kind              TEXT NOT NULL,
  agent_thread_id   TEXT,
  agent_path        TEXT,
  payload           TEXT NOT NULL,
  source_path       TEXT NOT NULL,
  source_line_no    INTEGER NOT NULL,
  collector_version INTEGER NOT NULL,
  -- Same dedup shape as turn_raw's (session_row_id, natural_turn_id): one
  -- line in one session's file identifies at most one row. Without it,
  -- `INSERT OR IGNORE` in the collector has nothing to ignore against, and a
  -- line reprocessed for any reason inserts a duplicate rather than a no-op.
  UNIQUE (session_row_id, source_line_no)
);

CREATE INDEX idx_activity_session_ts ON agent_activity_raw(session_row_id, ts);
"""

_V3 = """
-- turn_norm shipped with only capacity_primary_* columns on the documented
-- assumption that Codex's `rate_limits.secondary` was unpopulated in
-- practice (true of every sample the schema was designed against). A
-- 16,260-row real-corpus check during the normalization pass that consumes
-- this table found secondary populated in 7.7% of rows — not negligible.
-- Columns named to mirror `capacity_primary_*` exactly, for the same reason
-- those were named `primary` rather than assuming which window they meant:
-- `rate_limits.primary` itself is not reliably "the weekly window" (real
-- data shows both a 300-minute and a 10080-minute value under that name),
-- so neither field is given interpretive meaning — both are stored verbatim
-- under Codex's own naming, and a consumer distinguishes them by the
-- window_minutes value actually stored, not by the column name alone.
ALTER TABLE turn_norm ADD COLUMN capacity_secondary_used_pct REAL;
ALTER TABLE turn_norm ADD COLUMN capacity_secondary_window_minutes INTEGER;
ALTER TABLE turn_norm ADD COLUMN capacity_secondary_resets_at INTEGER;
"""

_V4 = """
-- Genuine last-write-wins for Claude's `ai-title` records, which chunk 6
-- shipped as "first one wins, forever" (`WHERE title IS NULL`) because a
-- real last-write-wins needs to know which of several repeats came last.
-- A first design assumed the record itself carries a timestamp to compare —
-- wrong: all 6,340 real `custom-title`/`ai-title` records sampled on the
-- machine this was built on carry only `{type, aiTitle|customTitle,
-- sessionId}`, nothing else. What real data DOES have: records immediately
-- adjacent to a title line (user/assistant/system/...) usually carry a real
-- `timestamp`, and JSONL is strictly append-only, so the nearest preceding
-- timestamped record bounds when the title event actually happened.
--
-- `last_seen_ts` is a running high-water mark, advanced from every record
-- type that carries a `timestamp` (not just titles) — this is what makes an
-- `ai-title` record's *effective* timestamp available at all, despite having
-- none of its own. `title_source` records which kind last won (`custom`
-- always locks out every future `ai-title`, permanently, regardless of that
-- future record's effective timestamp). `title_ai_ts` is the effective
-- timestamp in force when the current title's `ai-title` write (if any) was
-- accepted, so a later-arriving `ai-title` can be compared against it.
--
-- Two title records with nothing timestamped between them (common — several
-- other record types carry no timestamp either) share one effective
-- timestamp, so only the first of that tied cluster is accepted — this does
-- not reconstruct a true last-line-wins for back-to-back repeats with no
-- time information between them. It does correctly resolve genuine
-- time-separated re-titling and the rare case of one session's title
-- records spread across more than one file (1 of 163 real sessions with any
-- title records, from a session-continuation event) — a purely in-memory or
-- file-local-line-number ordinal would get both of those wrong.
--
-- All three columns are NULL on every session that predates this migration.
-- This self-heals via `flow harvest claude --backfill`: replaying a file's
-- lines in original order re-derives all three correctly, converging to the
-- same terminal state chunk 6's tests already proved is order-independent —
-- but the self-heal only happens once that backfill actually runs.
ALTER TABLE session ADD COLUMN title_source TEXT CHECK (title_source IN ('custom', 'ai'));
ALTER TABLE session ADD COLUMN title_ai_ts TEXT;
ALTER TABLE session ADD COLUMN last_seen_ts TEXT;
"""

_V5 = """
-- Claude's `usage.cache_creation` carries the cache-TTL breakdown
-- (`ephemeral_1h_input_tokens`, `ephemeral_5m_input_tokens`) that
-- `data/harness_capabilities.json` has claimed as supported for this harness
-- since v1 while nothing extracted it. The two sum exactly to
-- `cache_creation_input_tokens` — verified across 20,587 real turns, exact
-- match, no rounding — so this is not new measurement, it is a split of a
-- number already stored.
--
-- It matters because the halves bill 60% apart: a 1h write costs 2.0x base
-- input, a 5m write 1.25x. Collapsing them into one column makes the write
-- component of any cost estimate off by up to that much, and writes are about
-- a quarter of the bill.
--
-- `cache_write_tokens` deliberately stays as the total rather than being
-- superseded. It is what Codex reports (that harness has no TTL split at all,
-- and `harness_capability` already says so), and it is what every existing
-- consumer reads. Both new columns are nullable INTEGER precisely so "Codex,
-- which cannot report this" and "Claude, which reported zero" stay
-- distinguishable — the same NULL-versus-zero rule the rest of turn_norm keeps.
--
-- No re-harvest. The raw payload has always held these fields verbatim, so
-- bumping NORM_VERSION 1 -> 2 is the whole backfill mechanism; see
-- `cli/normalize.py`. That same bump also re-reads the payloads corrected by
-- collector v3's output upsert, so the two changes compose into one pass
-- rather than needing a mechanism each.
ALTER TABLE turn_norm ADD COLUMN cache_write_1h_tokens INTEGER;
ALTER TABLE turn_norm ADD COLUMN cache_write_5m_tokens INTEGER;
"""

_V6 = """
-- Sampling harness-maintained counters into flow's own history. Distinct from
-- every prior migration in this file: `pluginUsage` and `skillUsage` in
-- `~/.claude.json` are not a transcript or a derivation of one, they are live
-- state the harness mutates on its own schedule. flow did not create these
-- numbers and cannot re-derive them from anything else on disk, so unlike
-- `turn_norm` there is no raw/derived split here — there is only one layer,
-- `plugin_usage_observation`, holding exactly what was read, verbatim, at the
-- moment it was read.
--
-- WHY THE UNIQUE KEY IS OVER OBSERVED STATE, NOT OBSERVATION TIME
--
-- Two independent writers watch this file: a SessionStart hook (fast, frequent,
-- best-effort) and the `flow harvest claude` backstop (slower, guaranteed).
-- Both read the same `~/.claude.json` and nothing coordinates them. A key on
-- when-observed (`observed_at`, or a bare autoincrement id) makes every
-- double-observation of one file state a duplicate row — and worse, whichever
-- writer runs second computes its delta against the row the first just wrote,
-- so a real +47 gets stored as +0 purely because of arrival order. That is a
-- wrong number that looks confident, the one failure mode this codebase treats
-- as worse than a blank.
--
-- Keying on `(harness, host_id, kind, name, usage_count, source_mtime)` makes
-- the *content* of an observation its own identity. Two writers that saw the
-- same file revision produce identical rows and `INSERT OR IGNORE` makes the
-- second a no-op — order stops mattering because there is nothing left for
-- order to affect. Two writers that saw genuinely different revisions produce
-- two real rows, both true, both kept. A counter reset lands here too: a
-- reinstalled plugin reporting `usage_count = 0` again collides with nothing,
-- because `source_mtime` moved. This mirrors the dual-write identity the store
-- already relies on for `turn_raw` (`session_row_id, natural_turn_id`) and
-- `agent_activity_raw` (`session_row_id, source_line_no`).
--
-- The application-level guard — skip the insert when the latest stored count
-- for a name already equals the observed one — still lives in
-- `plugin_usage.py`, not here. The UNIQUE key is not a substitute for it; it is
-- what makes that guard's inherent TOCTOU race harmless instead of corrupting.
-- Application logic decides what is worth writing, the constraint decides what
-- counts as the same fact.
--
-- WHY THERE IS NO `delta` COLUMN
--
-- Delta is `usage_count` minus the previous row's for the same
-- (harness, host_id, kind, name), and "previous" only has stable meaning once
-- a series is ordered by `source_mtime` — the harness's own revision clock —
-- rather than `observed_at`, which is merely when flow happened to look.
-- Storing delta at write time bakes in whichever ordering the inserting writer
-- believed was current, and under two writers that belief is exactly what
-- cannot be trusted. A counter reading is raw; a delta is derived. One
-- `LAG(...) OVER (PARTITION BY harness, host_id, kind, name
-- ORDER BY source_mtime, rowid)` at read time costs nothing to get right every
-- time it is asked, against a write-time race that gets it wrong once and
-- keeps it.
--
-- WHY THERE IS NO `enabled` COLUMN
--
-- Plugin enablement lives in `enabledPlugins` in `~/.claude/settings.json` — a
-- different file, written by a different process, and on at least one machine a
-- symlink into a dotfiles repo whose contents can change via `git pull` with
-- the harness never involved. A row here means "the harness reported this
-- counter value at this file revision." Adding `enabled` would make every row
-- additionally claim "and this is whether the plugin was enabled at that
-- instant" — a claim this table cannot verify, since the two files are read on
-- unrelated schedules. Resolved live at render time instead, following the
-- read-time-inference precedent set for context windows: never write an
-- inferred or externally-sourced value into a column meaning "the harness
-- reported this."
--
-- WHAT A RESET LOOKS LIKE IN THE DATA
--
-- Within one install `usage_count` cannot decrease; a reinstall or a config
-- edit clearing the counter is the only way a later row reads lower than its
-- predecessor for the same name. Nothing flags that at write time. A reset is
-- just two ordinary rows where the second's `usage_count` is below its
-- `source_mtime`-ordered predecessor, and the read model is the only place that
-- classifies it. When it does, that row's delta renders blank — never negative,
-- and never zero, because zero would report "no change" when the truth is "the
-- history before this point stopped being comparable."
--
-- WHY ONE TABLE SERVES BOTH MAPS DESPITE OPPOSITE ZERO-SEMANTICS
--
-- `pluginUsage` is seeded at install, so a present `usage_count = 0` means
-- "installed, never used" — a real and reportable fact. `skillUsage` is written
-- only on first use, so no skill row at zero exists; an unused skill is simply
-- absent from the map until first invoked. This table stores what the harness
-- wrote and nothing else: plugin zeros are real rows because the harness
-- reported them, and skill zeros are never synthesized, because that would put
-- an invented reading into a column whose contract is "the harness reported
-- this." The resulting asymmetry — this table can hold a population of
-- never-used plugins but never one of never-used skills — is real, and it is
-- the read model's job to say so out loud rather than the schema's job to paper
-- over.
--
-- NAMES STORED VERBATIM
--
-- `security-guidance@claude-plugins-official` and `security-guidance@inline`
-- are one plugin surfaced under two map keys. Splitting the key at write time
-- would put a parsed value in a column meaning "the map key exactly as the
-- harness wrote it", and would break the day a key contains an unexpected `@`.
-- The base-name fold happens only in the read model, and it never sums the two:
-- whether those counters double-count the same invocations or count disjoint
-- ones is unverified, and summing them would manufacture a total this store
-- cannot back up.
CREATE TABLE plugin_usage_observation (
  harness      TEXT NOT NULL,
  host_id      TEXT NOT NULL DEFAULT '',
  kind         TEXT NOT NULL CHECK (kind IN ('plugin', 'skill')),
  name         TEXT NOT NULL,          -- verbatim map key, namespace included
  usage_count  INTEGER NOT NULL,       -- as reported; never synthesized
  last_used_at TEXT,                   -- as reported; NULL when the harness omits it
  source_mtime REAL NOT NULL,          -- mtime of the source file for this revision
  observed_at  TEXT NOT NULL,          -- when flow first saw this state; not an ordering key
  UNIQUE (harness, host_id, kind, name, usage_count, source_mtime)
);

CREATE INDEX ix_plugin_usage_series
  ON plugin_usage_observation (harness, host_id, kind, name, source_mtime);

-- The "have we looked" watermark, kept apart from `harvest` on purpose:
-- `harvest`'s columns (`last_offset`, `last_line_no`, `last_line_hash`) carry
-- JSONL-stream semantics that do not apply to a single JSON document, and
-- `harvest`'s claude rescan filters select `WHERE harness = 'claude'` — reusing
-- that table would pull a non-transcript row into a code path reasoning about
-- transcript rescans and zero it during an unrelated one.
--
-- `scope` generalizes the watermark to more than one kind of "have we looked":
-- the counters file (`source_path` = the config path, `scope = ''`) and,
-- separately, an installed-skill-inventory walk rooted at a working directory
-- (`source_path = 'skill-inventory'`, `scope` = that root). The inventory needs
-- a scope because `skillUsage` holds no zeros, so "which skills are unused"
-- depends on enumerating installed skills — and that enumeration is
-- directory-dependent once project-local skills count. Without recording the
-- root, a later read cannot tell "absent because never invoked" from "absent
-- because this scan never looked where it lives", and comparing two such
-- enumerations as one population would manufacture exactly the confident-wrong
-- claim this feature exists to prevent.
CREATE TABLE plugin_usage_scan (
  harness     TEXT NOT NULL,
  host_id     TEXT NOT NULL DEFAULT '',
  source_path TEXT NOT NULL,
  scope       TEXT NOT NULL DEFAULT '',
  last_mtime  REAL NOT NULL,
  scanned_at  TEXT NOT NULL,
  PRIMARY KEY (harness, host_id, source_path, scope)
);
"""

MIGRATIONS: list[tuple[int, str, str]] = [
    (1, "initial schema: raw + normalized layers, harvest watermark, capabilities", _V1),
    (2, "agent activity log for sub-agent telemetry with no local token data", _V2),
    (3, "secondary capacity window columns on turn_norm", _V3),
    (4, "title provenance and a session-level timestamp high-water mark", _V4),
    (5, "cache-TTL split columns on turn_norm", _V5),
    (6, "plugin and skill usage counter observations, scoped scan watermark", _V6),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _user_version(conn: sqlite3.Connection) -> int:
    return int(conn.execute("PRAGMA user_version").fetchone()[0])


def _ledger_version(conn: sqlite3.Connection) -> int:
    """Highest migration ledger entry present, or 0 when no ledger exists yet."""
    exists = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'schema_migration'"
    ).fetchone()
    if exists is None:
        return 0
    return int(
        conn.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migration").fetchone()[0]
    )


def pending_migrations(current: int) -> list[tuple[int, str, str]]:
    return [m for m in MIGRATIONS if m[0] > current]


def ensure_store(
    path: Path, capabilities_path: Path | None = None
) -> tuple[bool, list[int]]:
    """Create the store if absent and apply any pending migrations.

    Returns (created, applied_versions). Idempotent: safe to run on every
    `flow setup machine` and every release update.

    Each migration's ledger row and `user_version` pragma commit together —
    but the DDL itself does not, despite the comment on the `with` block
    below suggesting so: `executescript` implicitly commits any open
    transaction before running, so the ALTER/CREATE statements land outside
    it. A crash in the narrow window between the DDL and the ledger commit
    leaves the columns present with the old `user_version`. Recovery below
    trusts committed ledger rows when they are ahead of `user_version`, and
    v1 is safe to replay so a store with the initial tables but no ledger row
    can resume instead of failing on "table already exists."
    """
    created = not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)

    applied: list[int] = []
    conn = _connect(path)
    try:
        current = _user_version(conn)
        ledger_current = _ledger_version(conn)
        if ledger_current > current:
            with conn:
                conn.execute(f"PRAGMA user_version = {ledger_current}")
            current = ledger_current
        for version, description, sql in pending_migrations(current):
            with conn:  # ledger row + pragma commit together; DDL precedes (see docstring)
                conn.executescript(sql)
                conn.execute(
                    "INSERT OR IGNORE INTO schema_migration (version, applied_at, description)"
                    " VALUES (?, ?, ?)",
                    (version, _now(), description),
                )
                conn.execute(f"PRAGMA user_version = {version}")
            applied.append(version)

        if capabilities_path is not None and capabilities_path.is_file():
            _seed_capabilities(conn, capabilities_path)
    finally:
        conn.close()

    return created, applied


def _seed_capabilities(conn: sqlite3.Connection, capabilities_path: Path) -> None:
    """Upsert the shipped capability rows.

    Re-seeded on every ensure_store so a harness added to the data file — or a
    field a harness starts reporting — lands without a code change. Only
    touches harness_capability; no other table is read or written.
    """
    data = json.loads(capabilities_path.read_text())
    rows = [
        (row["harness"], row["field"], int(row["supported"]))
        for row in data.get("capabilities", [])
    ]
    if not rows:
        return
    with conn:
        conn.executemany(
            "INSERT INTO harness_capability (harness, field, supported)"
            " VALUES (?, ?, ?)"
            " ON CONFLICT(harness, field) DO UPDATE SET supported = excluded.supported",
            rows,
        )


def store_status(path: Path) -> dict:
    """Report the store's state without creating or modifying anything.

    Read-only by contract. `sqlite3.connect` would create an empty file, so an
    absent store is detected by path check before any connection is opened —
    otherwise asking about the store would bring it into existence and the
    absent state could never be observed.
    """
    if not path.exists():
        return {"state": STATE_ABSENT, "path": path}

    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except sqlite3.Error as exc:
        return {"state": STATE_ERROR, "path": path, "error": str(exc)}

    try:
        version = _user_version(conn)
        pending = [m[0] for m in pending_migrations(version)]
        if pending:
            return {
                "state": STATE_STALE,
                "path": path,
                "user_version": version,
                "pending": pending,
            }
        turns = int(conn.execute("SELECT count(*) FROM turn_raw").fetchone()[0])
        sessions = int(conn.execute("SELECT count(*) FROM session").fetchone()[0])
        return {
            "state": STATE_EMPTY if turns == 0 else STATE_OK,
            "path": path,
            "user_version": version,
            "sessions": sessions,
            "turns": turns,
        }
    except sqlite3.Error as exc:
        return {"state": STATE_ERROR, "path": path, "error": str(exc)}
    finally:
        conn.close()


def format_status(status: dict) -> str:
    """One-line summary for `flow doctor`.

    Every state renders something. An omitted line would be indistinguishable
    from a healthy store with nothing in it.
    """
    state = status["state"]
    if state == STATE_ABSENT:
        return "not created — run `flow setup machine`"
    if state == STATE_ERROR:
        return f"error — {status.get('error', 'unreadable')}"
    if state == STATE_STALE:
        pending = ", ".join(str(v) for v in status["pending"])
        return (
            f"stale, {len(status['pending'])} pending (v{pending})"
            " — run `flow setup machine`"
        )
    if state == STATE_EMPTY:
        return f"ok, empty (schema v{status['user_version']}, no turns harvested)"
    return (
        f"ok (schema v{status['user_version']}, "
        f"{status['sessions']} sessions, {status['turns']} turns)"
    )

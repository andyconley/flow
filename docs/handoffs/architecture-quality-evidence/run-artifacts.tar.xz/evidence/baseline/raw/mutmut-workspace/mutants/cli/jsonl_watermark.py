"""Incremental byte-level reading of append-only JSONL files.

Harness-agnostic: nothing here knows about Codex or Claude, only about the
one property both harnesses' transcripts share — a file that is appended to
over time, one JSON object per line, sometimes mid-write. Extracted out of
`codex_collector.py` rather than duplicated into `claude_collector.py`, since
none of it had any Codex-specific content to begin with.

Decoding happens in the caller, not here: lines are returned as raw bytes, so
a decode failure and a JSON-parse failure can funnel through the same
hard-stop path in whichever collector calls this.
"""

import hashlib
from pathlib import Path


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class WatermarkAnomaly(Exception):
    """The file is smaller than the recorded watermark. Never a silent no-op.

    A file that shrank was not appended to — it was replaced or truncated.
    Silently re-harvesting from 0 would either skip data or double-count it
    depending on what actually happened, so this is raised rather than guessed
    at.
    """
mutants_x_read_new_lines__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_new_lines__mutmut)
def read_new_lines(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_orig(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_1(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = None
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_2(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size <= last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_3(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            None
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_4(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size != last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_5(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open(None) as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_6(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("XXrbXX") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_7(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("RB") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_8(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(None)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_9(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = None

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_10(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = None
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_11(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = None
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_12(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 1
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_13(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while False:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_14(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = None
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_15(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(None, start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_16(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", None)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_17(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_18(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", )
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_19(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.rfind(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_20(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"XX\nXX", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_21(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl != -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_22(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == +1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_23(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -2:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_24(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            return  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_25(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(None)
        start = nl + 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_26(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = None
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_27(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl - 1
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_28(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 2
    new_offset = last_offset + start
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_29(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = None
    return lines, new_offset, current_size


def x_read_new_lines__mutmut_30(path: Path, last_offset: int) -> tuple[list[bytes], int, int]:
    """Read complete lines appended since `last_offset`, as raw bytes.

    Returns `(lines, new_offset, current_size)`. `new_offset` is the byte
    offset immediately after the last complete line — what the caller should
    persist as `harvest.last_offset` once those lines are committed. A
    trailing line with no terminating newline is left unread entirely; it is
    neither returned nor counted toward `new_offset`.
    """
    current_size = path.stat().st_size
    if current_size < last_offset:
        raise WatermarkAnomaly(
            f"{path}: size {current_size} < recorded offset {last_offset}"
        )
    if current_size == last_offset:
        return [], last_offset, current_size

    with path.open("rb") as fh:
        fh.seek(last_offset)
        chunk = fh.read()

    lines: list[bytes] = []
    start = 0
    while True:
        nl = chunk.find(b"\n", start)
        if nl == -1:
            break  # remainder, if any, is an incomplete trailing line
        lines.append(chunk[start:nl])
        start = nl + 1
    new_offset = last_offset - start
    return lines, new_offset, current_size

mutants_x_read_new_lines__mutmut['_mutmut_orig'] = x_read_new_lines__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_1'] = x_read_new_lines__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_2'] = x_read_new_lines__mutmut_2 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_3'] = x_read_new_lines__mutmut_3 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_4'] = x_read_new_lines__mutmut_4 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_5'] = x_read_new_lines__mutmut_5 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_6'] = x_read_new_lines__mutmut_6 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_7'] = x_read_new_lines__mutmut_7 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_8'] = x_read_new_lines__mutmut_8 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_9'] = x_read_new_lines__mutmut_9 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_10'] = x_read_new_lines__mutmut_10 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_11'] = x_read_new_lines__mutmut_11 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_12'] = x_read_new_lines__mutmut_12 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_13'] = x_read_new_lines__mutmut_13 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_14'] = x_read_new_lines__mutmut_14 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_15'] = x_read_new_lines__mutmut_15 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_16'] = x_read_new_lines__mutmut_16 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_17'] = x_read_new_lines__mutmut_17 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_18'] = x_read_new_lines__mutmut_18 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_19'] = x_read_new_lines__mutmut_19 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_20'] = x_read_new_lines__mutmut_20 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_21'] = x_read_new_lines__mutmut_21 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_22'] = x_read_new_lines__mutmut_22 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_23'] = x_read_new_lines__mutmut_23 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_24'] = x_read_new_lines__mutmut_24 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_25'] = x_read_new_lines__mutmut_25 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_26'] = x_read_new_lines__mutmut_26 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_27'] = x_read_new_lines__mutmut_27 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_28'] = x_read_new_lines__mutmut_28 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_29'] = x_read_new_lines__mutmut_29 # type: ignore # mutmut generated
mutants_x_read_new_lines__mutmut['x_read_new_lines__mutmut_30'] = x_read_new_lines__mutmut_30 # type: ignore # mutmut generated
mutants_x_line_byte_length__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_line_byte_length__mutmut)
def line_byte_length(raw: bytes) -> int:
    return len(raw) + 1  # +1 for the newline stripped during reading


def x_line_byte_length__mutmut_orig(raw: bytes) -> int:
    return len(raw) + 1  # +1 for the newline stripped during reading


def x_line_byte_length__mutmut_1(raw: bytes) -> int:
    return len(raw) - 1  # +1 for the newline stripped during reading


def x_line_byte_length__mutmut_2(raw: bytes) -> int:
    return len(raw) + 2  # +1 for the newline stripped during reading

mutants_x_line_byte_length__mutmut['_mutmut_orig'] = x_line_byte_length__mutmut_orig # type: ignore # mutmut generated
mutants_x_line_byte_length__mutmut['x_line_byte_length__mutmut_1'] = x_line_byte_length__mutmut_1 # type: ignore # mutmut generated
mutants_x_line_byte_length__mutmut['x_line_byte_length__mutmut_2'] = x_line_byte_length__mutmut_2 # type: ignore # mutmut generated
mutants_x_line_hash__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_line_hash__mutmut)
def line_hash(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def x_line_hash__mutmut_orig(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def x_line_hash__mutmut_1(raw: bytes) -> str:
    return hashlib.sha256(None).hexdigest()

mutants_x_line_hash__mutmut['_mutmut_orig'] = x_line_hash__mutmut_orig # type: ignore # mutmut generated
mutants_x_line_hash__mutmut['x_line_hash__mutmut_1'] = x_line_hash__mutmut_1 # type: ignore # mutmut generated
